# Data Dictionary Supplement — Supplier Fields & Renamed Columns

This supplements the Week 3 `data_dictionary.md` already delivered. It covers only
what is new or renamed in `merged_dataset_WITH_SUPPLIER.csv`.

## New: supplier fields (previously missing entirely)

| Column | Description |
| :--- | :--- |
| `supplier_id` | Primary supplier assigned to the product on this row (see assignment rule below) |
| `supplier_name` | Supplier's name |
| `supplier_type` | OEM / Distributor / Local Vendor |
| `product_category` | Product category this supplier is registered to supply (supplier-level field; compare against the row's own `category`) |
| `supplier_city`, `supplier_province`, `supplier_region`, `supplier_pincode` | Supplier location |
| `supplier_lead_time_days` | Supplier's typical lead time |
| `reliability_score` | Supplier reliability score |
| `import_duty_rate` | Import duty rate applicable to this supplier |
| `china_tax_id` | Supplier's China tax ID (populated for overseas suppliers) |

**Assignment rule:** each product's supplier is taken from its most recent purchase
order (`purchase_orders_lines` → `purchase_orders_header` → `suppliers`), since a
product can appear on POs from more than one supplier over time.

## Renamed columns (to resolve name collisions across source tables)

Several raw source tables use the same column name for different things (e.g. every
one of `products`, `customers`, `branches`, and `suppliers` has its own `city` /
`region` style fields). These were renamed before merging so nothing is ambiguous:

| Original column | Source table | Renamed to |
| :--- | :--- | :--- |
| `unit_price` | products | `product_list_price` |
| `gst_rate` | products | `product_gst_rate` |
| `lead_time_days` | products | `product_lead_time_days` |
| `last_purchase_date` | products | `product_last_purchase_date` |
| `city` | customers | `customer_city` |
| `state` | customers | `customer_state` |
| `region` | customers | `customer_region` |
| `pincode` | customers | `customer_pincode` |
| `branch_id` | customers | `customer_home_branch_id` (distinct from the order's fulfilling `branch_id`) |
| `payment_terms` | customers | `customer_payment_terms` |
| `last_purchase_date` | customers | `customer_last_purchase_date` |
| `city` | branches | `branch_city` |
| `state` | branches | `branch_state` |
| `region` | branches | `branch_region` |
| `city` | suppliers | `supplier_city` |
| `province` | suppliers | `supplier_province` |
| `region` | suppliers | `supplier_region` |
| `pincode` | suppliers | `supplier_pincode` |
| `lead_time_days` | suppliers | `supplier_lead_time_days` |
| `payment_terms` | sales order header | `order_payment_terms` |

`unit_price` (the line-item's actual sale price, from `sales_orders_lines`) and
`gst_rate` (the line-item's actual GST rate) keep their original names, since those
are the two in active use throughout the existing KPI notebooks and summaries —
only the *products catalog's* price/rate fields were renamed, to avoid colliding
with them.
